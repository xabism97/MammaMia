from django.apps import AppConfig


class MammamiaappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mammamiaapp'
